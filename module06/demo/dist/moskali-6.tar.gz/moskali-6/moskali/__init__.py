from moskali.main import main
