class NotInRange(Exception):
    pass
